# OIBSIP-Level1-Task3
This is the Task-3 of Level-1 of the Oasis Infobyte Internship. Here, In this task, I have built the Temperature Converter Website where the user will have to input a temperature that should be either in Fahrenheit or in Celsius and then press a "convert" button. After that The converted temperature will then be displayed with the correct unit.
